/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Match_Finder;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.font.TextAttribute;
import java.util.Map;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author win10
 */
public class PanelImg extends JPanel {
    int perid;
    ImageIcon ic;
    Image im;
    ImageIcon newImage;
    JLabel img;
    JLabel l2;
    JLabel l3;
    public PanelImg(byte [] ar,int rec,String nam, int id)
    {
        perid=id;
        BoxLayout layout = new BoxLayout(this,BoxLayout.Y_AXIS);
        //GridLayout layout = new GridLayout(3,1);
        //FlowLayout layout = new FlowLayout();
        //layout.setVgap(5);
        //layout.setHgap(5);
        this.setSize(200,250);
        this.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        this.setLayout(layout);
        img=new JLabel("");
        img.setSize(135,150);
        ic=new ImageIcon(ar);
        im=ic.getImage().getScaledInstance(img.getWidth(),img.getHeight(),Image.SCALE_SMOOTH);
        newImage=new ImageIcon(im);
        img.setIcon(newImage);
        l2=new JLabel(rec+"");
        l2.setVisible(false);
        l3=new JLabel(nam);
        l3.setFont(new Font("Arial",Font.BOLD,18));
        this.add(img);
        this.add(l2);
        this.add(l3);
        this.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panMouseExited(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                panMousePressed(evt);
            }
        });
    }
    
    
    
    
    private void panMousePressed(java.awt.event.MouseEvent evt) { 
        new Show(perid,Integer.parseInt(l2.getText())).setVisible(true);
    }
    private void panMouseEntered(java.awt.event.MouseEvent evt) { 
        this.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        Font fon=l3.getFont();
        Map attributes = fon.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
        l3.setFont(fon.deriveFont(attributes));
        l3.setForeground(Color.BLUE);
    }
    private void panMouseExited(java.awt.event.MouseEvent evt) { 
        Font fon=l3.getFont();
        Map attributes = fon.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE);
        l3.setFont(fon.deriveFont(attributes));
        l3.setForeground(Color.BLACK);
    }
    
}
